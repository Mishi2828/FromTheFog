import { system, world } from "@minecraft/server";
import { ModalFormData, ActionFormData } from "@minecraft/server-ui";
import { ObsidianAPI } from "../API/ObsidianAPI";
import { eventsTriggerList } from "../eventTrigger";
import { ADDON_SETTINGS_ID } from "../eventFormat";

const { DynamicManager, Utils } = ObsidianAPI;

system.beforeEvents.startup.subscribe((event) => {
    event.itemComponentRegistry.registerCustomComponent("hrb:herobrineSettings_component", {
        onUse: GUI_mainMenu
    });
});

export function GUI_mainMenu(event) {
    const player = event.sourceEntity || event.source;

    const permissionChecker = player.commandPermissionLevel === 1 || player.commandPermissionLevel === 3;

    if (!permissionChecker) {
        player.sendMessage({ translate: "warning.permissionFailed" });
        return;
    }

    const addonData = DynamicManager.fetch(ADDON_SETTINGS_ID);

    if (!addonData) {
        player.sendMessage({ translate: "warning.dynamicFailed" });
        return;
    }

    const form = new ActionFormData();
    form.title({ translate: "gui.main.title" });
    form.body({ translate: "gui.main.body" });
    addonData.totemEnable
        ? form.button({ translate: "herobrine.totemDisable" })
        : form.button({ text: "§c", translate: "herobrine.totemEnable" });
    form.divider();
    form.button({ translate: "gui.main.button1" }); // Configurações
    form.button({ translate: "gui.main.button2" }); // Eventos ativos
    form.button({ translate: "gui.main.button3" }); // Eventos instant

    form.show(player).then((res) => {
        if (res.canceled) return;
        const { selection } = res;
        switch (selection) {
            case 0:
                addonData.totemEnable = !addonData.totemEnable;
                addonData.initialDay = world.getDay();
                DynamicManager.write(ADDON_SETTINGS_ID, addonData);
                player.sendMessage({ translate: addonData.totemEnable ? "warning.totemEnable" : "warning.totemDisable" });
                break;
            case 1:
                GUI_settings(player);
                break;
            case 2:
                GUI_eventsList(player, "settings");
                break;
            case 3:
                GUI_eventsList(player, "instant");
                break;
        }
    });
}

export function GUI_settings(player) {
    const addonData = DynamicManager.fetch(ADDON_SETTINGS_ID);

    const form = new ModalFormData();
    form.title({ translate: "gui.settings.title" });
    form.textField({ translate: "gui.settings.textField" }, String(addonData.timerSettings.nextEventTimeDefault));
    form.slider({ translate: "gui.settings.slider" }, 0, addonData.fogDistanceMax, { defaultValue: addonData.fogDistance, valueStep: 1, tooltip: "gui.settings.slider.tooltip" });
    form.toggle({ translate: "gui.settings.toggle1" }, { defaultValue: addonData.VFX });
    form.toggle({ translate: "gui.settings.toggle2" }, { defaultValue: addonData.bloodMoon });
    form.toggle({ translate: "gui.settings.toggle3" }, { defaultValue: addonData.hiddenNickname });

    form.show(player).then((response) => {
        if (response.canceled) return;

        // Mapear os valores retornados
        const [nextEventTimeDefault, fogDistance, VFX, bloodMoon, hiddenNickname] = response.formValues;

        const textFieldFix = nextEventTimeDefault.trim() ? nextEventTimeDefault.split(",").map(v => Number(v.trim())).filter(n => !isNaN(n)) : [];
        const textField = textFieldFix.length > 0 ? textFieldFix : addonData.timerSettings.nextEventTimeDefault;

        if (addonData.fogDistance !== fogDistance) {
            world.getAllPlayers().forEach(player => { player.runCommand(`fog @s remove fog`) });
        }

        addonData.fogDistance = fogDistance;
        addonData.VFX = VFX;
        addonData.bloodMoon = bloodMoon;
        addonData.hiddenNickname = hiddenNickname;
        addonData.timerSettings.nextEventTimeDefault = textField;

        DynamicManager.write(ADDON_SETTINGS_ID, addonData);
        player.sendMessage({ translate: "gui.mainSettings.saved" });
    });
}

export function GUI_eventsList(player, mode) {
    const addonData = DynamicManager.fetch(ADDON_SETTINGS_ID);

    const form = new ActionFormData();
    form.title({ translate: mode === "settings" ? "gui.activeEventList.title" : "gui.instantEventList.title" });
    form.body({ translate: mode === "settings" ? "gui.activeEventList.body" : "gui.instantEventList.body" });
    form.divider();

    const eventKeys = Object.keys(addonData.eventsId);
    for (let eventKey of eventKeys) {
        const eventData = addonData.eventsId[eventKey];
        form.button({ text: `${eventData.eventNameText}` }, mode === "settings" ? eventData.active ? "textures/ui/confirm.png" : "textures/ui/cancel.png" : "");
    }

    form.show(player).then((res) => {
        if (res.canceled) return;
        const { selection } = res;
        const selectedEventKey = eventKeys[selection];
        if (!selectedEventKey) return;

        if (mode === "settings") {
            GUI_eventSettings(player, selectedEventKey);
        } else if (mode === "instant") {
            GUI_activeEventInstant(player, selectedEventKey);
        }
    });
}

export function GUI_eventSettings(player, eventKey) {
    const addonData = DynamicManager.fetch(ADDON_SETTINGS_ID);
    const eventData = addonData.eventsId[eventKey];

    const form = new ModalFormData();
    form.title({ translate: eventData.eventNameText });
    form.label({ translate: eventData.eventDescriptionText });
    form.divider();
    form.toggle({ translate: "gui.eventSettings.toggle" }, { defaultValue: eventData.active });
    form.slider({ translate: "gui.eventSettings.slider" }, 1, 100, { defaultValue: eventData.probability * 100, valueStep: 1 });
    form.textField({ translate: "gui.eventSettings.textField" }, String(eventData.eventTime));

    if (eventData?.extraButtons) {
        for (let button of eventData.extraButtons) {
            form.toggle({ translate: button.text }, { defaultValue: button.value, tooltip: button?.tooltip ? { translate: button.tooltip } : "" });
        }
    }

    form.show(player).then((response) => {
        if (response.canceled) return;

        eventData.active = response.formValues[2];
        eventData.probability = Number(response.formValues[3]) / 100;
        eventData.eventTime = response.formValues[4].length > 0 ? response.formValues[4].split(",").map(Number) : eventData.eventTime;

        if (eventData?.extraButtons) {
            eventData.extraButtons.forEach((button, index) => {
                button.value = response.formValues[5 + index];
            });
        }

        addonData.eventsId[eventKey] = eventData;
        DynamicManager.write(ADDON_SETTINGS_ID, addonData);
        player.sendMessage({ translate: "gui.eventSettings.saved" });
    });
}

export function GUI_activeEventInstant(player, eventKey) {
    const addonData = DynamicManager.fetch(ADDON_SETTINGS_ID);
    const eventData = addonData.eventsId[eventKey];
    const players = world.getAllPlayers();

    const form = new ModalFormData();
    form.title({ translate: eventData.eventNameText });
    form.label({ translate: eventData.eventDescriptionText });
    form.divider();
    form.dropdown({ translate: "gui.activeInstant.dropdown" }, players.map(player => player.name), { defaultValueIndex: 0 });
    form.textField({ translate: "gui.activeInstant.textField" }, String(eventData.eventTime));

    form.show(player).then((response) => {
        if (response.canceled) return;

        const [playerIndex, textField] = response.formValues.slice(-2);
        const playerSelected = players[playerIndex];

        if (!playerSelected) return;

        const textFieldValues = textField.trim() ? textField.split(",").map(v => Number(v.trim())).filter(n => !isNaN(n)) : [];

        const eventsList = new eventsTriggerList(playerSelected, eventKey);

        // Atualiza informações globais
        if (textFieldValues.length > 0) {
            addonData.timerSettings.eventTime = textFieldValues[Utils.randomNumber(0, textFieldValues.length - 1)];
        } else {
            addonData.timerSettings.eventTime = eventData.eventTime[Utils.randomNumber(0, eventData.eventTime.length - 1)];
        }

        addonData.targetID = playerSelected.id;
        addonData.targetDimension = playerSelected.dimension;
        addonData.timerSettings.nextEventTime = addonData.timerSettings.nextEventTimeDefault[Utils.randomNumber(0, addonData.timerSettings.nextEventTimeDefault.length - 1)];
        addonData.eventsPassList.unshift(eventKey);

        DynamicManager.write(ADDON_SETTINGS_ID, addonData);

        eventsList[eventData.trigger]();
        player.sendMessage({ translate: "gui.activeInstant.triggered", with: [playerSelected.name] });
    });
}
