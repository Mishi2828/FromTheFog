import { world } from "@minecraft/server";
import { ObsidianAPI } from "./API/ObsidianAPI";

const { Utils, DynamicManager } = ObsidianAPI;

export const dataComponents = new Date(); // Data para eventos especiais.

export const HEROBRINE_IDS = ["hrb:herobrine", "hrb:herobrine_stopped"];

export const MINECRAFT_TICK = 20;
export const ADDON_SETTINGS_ID = "herobrine_settings";
export const GLOBAL_TIMER_ID = "global_timer";

export function createStandardDynamic() {

    DynamicManager.update(GLOBAL_TIMER_ID, {
        subtimer: 0,
        timer: 0
    });

    DynamicManager.update(ADDON_SETTINGS_ID, {

        totemEnable: false,
        initialDay: 0,
        targetID: world.getAllPlayers()[Utils.randomNumber(0, world.getAllPlayers().length - 1)]?.id,
        targetDimension: world.getDimension("minecraft:overworld"),

        fogDistance: 1,
        fogDistanceMax: 5,

        hiddenNickname: true,

        ownVillager: false,
        bloodMoon: true,
        VFX: true,

        bloodMoonEvent: false,

        eventsPassList: [],
        eventsCacheSize: 2,

        eventsId: {
            // Dia 1 — introdução, observação e sustos leves
            "event_watching": {
                trigger: "watching",
                triggerLoop: "watchingLoop",
                dayUnlock: 0,
                probability: 0.65,
                eventNameText: "event.watching.name",
                eventDescriptionText: "event.watching.description",
                eventTime: [5, 10, 15, 20],
                active: true
            },
            "event_changeTorches": {
                trigger: "changeTorches",
                triggerLoop: null,
                dayUnlock: 0,
                probability: 0.35,
                eventNameText: "event.changeTorches.name",
                eventDescriptionText: "event.changeTorches.description",
                eventTime: [10, 20, 25],
                active: true
            },
            "event_watchingSub": {
                trigger: "watchingSub",
                triggerLoop: "watchingLoop",
                dayUnlock: 0,
                probability: 0.45,
                eventNameText: "event.watchingSub.name",
                eventDescriptionText: "event.watchingSub.description",
                eventTime: [10, 20, 25, 30],
                active: true
            },
            "event_randomFire": {
                trigger: "randomFire",
                triggerLoop: null,
                dayUnlock: 0,
                probability: 0.25,
                eventNameText: "event.randomFire.name",
                eventDescriptionText: "event.randomFire.description",
                eventTime: [25, 40, 60],
                active: false
            },
            "event_tunnel": {
                trigger: "tunnel",
                triggerLoop: null,
                dayUnlock: 0,
                probability: 0.20,
                eventNameText: "event.tunnel.name",
                eventDescriptionText: "event.tunnel.description",
                eventTime: [10, 20, 30],
                active: true
            },
            "event_scarySound": {
                trigger: "scarySound",
                triggerLoop: null,
                dayUnlock: 0,
                probability: 0.35,
                eventNameText: "event.scarySound.name",
                eventDescriptionText: "event.scarySound.description",
                eventTime: [10, 20, 30],
                active: true
            },

            // Dia 2 — começa a interagir e causar distúrbios no mundo
            "event_watchingScare": {
                trigger: "watchingScare",
                triggerLoop: "watchingLoop",
                dayUnlock: 1,
                probability: 0.45,
                eventNameText: "event.watchingScare.name",
                eventDescriptionText: "event.watchingScare.description",
                eventTime: [15, 25, 35],
                active: true
            },
            "event_chatMessage": {
                trigger: "chatMessage",
                triggerLoop: null,
                dayUnlock: 1,
                probability: 0.55,
                eventNameText: "event.chatMessage.name",
                eventDescriptionText: "event.chatMessage.description",
                eventTime: [15, 25, 35, 50],
                active: false
            },
            "event_ownAnimals": {
                trigger: "ownAnimals",
                triggerLoop: null,
                dayUnlock: 1,
                probability: 0.55,
                eventNameText: "event.ownAnimals.name",
                eventDescriptionText: "event.ownAnimals.description",
                eventTime: [25, 45, 65, 90],
                extraButtons: [
                    { text: "extraButton.ownAnimals.villager", value: false }
                ],
                active: true
            },
            "event_sign": {
                trigger: "sign",
                triggerLoop: null,
                dayUnlock: 1,
                probability: 0.25,
                eventNameText: "event.sign.name",
                eventDescriptionText: "event.sign.description",
                eventTime: [20, 30, 40],
                active: true
            },
            "event_hitScare": {
                trigger: "hitScare",
                triggerLoop: "hitScareLoop",
                dayUnlock: 1,
                probability: 0.30,
                eventNameText: "event.hitScare.name",
                eventDescriptionText: "event.hitScare.description",
                eventTime: [50, 70, 90, 110],
                active: true
            },

            // Dia 3 — eventos avançados e ataques diretos
            "event_attack": {
                trigger: "attack",
                triggerLoop: "attackLoop",
                dayUnlock: 2,
                probability: 0.30,
                eventNameText: "event.attack.name",
                eventDescriptionText: "event.attack.description",
                eventTime: [50, 70, 90, 120],
                active: true
            },
            "event_crashWorld": {
                trigger: "crashWorld",
                triggerLoop: null,
                dayUnlock: 2,
                probability: 0.18,
                eventNameText: "event.crashWorld.name",
                eventDescriptionText: "event.crashWorld.description",
                eventTime: [25, 40, 55],
                active: false
            }
        },

        timerSettings: {
            nextEventTime: 10,
            eventTime: 30,
            nextEventTimeDefault: [30, 45, 60, 70]
        }
    });
};
