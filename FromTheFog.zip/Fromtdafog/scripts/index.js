import { world, system, EntityComponentTypes, CommandPermissionLevel } from "@minecraft/server";
import { GLOBAL_TIMER_ID, ADDON_SETTINGS_ID, MINECRAFT_TICK, createStandardDynamic, HEROBRINE_IDS } from "./eventFormat";
import { eventsTriggerList, eventsTriggerLoop } from "./eventTrigger.js";
import { ObsidianAPI } from "./API/ObsidianAPI";

import "./customCommand.js";
import "./components/index.js";
import "./totemSystem/index.js";

const { DynamicManager, Utils } = ObsidianAPI;
const bloodMoonPhases = [3, 7];

let deferredWarning = false;

// world.afterEvents.itemUse.subscribe((event) => {
//     const { itemStack } = event;
//     if (itemStack.typeId === "minecraft:stick") {
//         world.clearDynamicProperties();
//     }
// })

world.afterEvents.worldLoad.subscribe(() => {
    createStandardDynamic();
});

world.afterEvents.entityHitEntity.subscribe(event => {
    const { hitEntity, damagingEntity } = event;

    const entitiesList = {
        "minecraft:chicken": "hrb:chicken",
        "minecraft:sheep": "hrb:sheep",
        "minecraft:cow": "hrb:cow",
        "minecraft:pig": "hrb:pig",
        "minecraft:bee": "hrb:bee",
    };

    // Verifica se quem bateu é o HEROBRINE
    if (damagingEntity.typeId === "hrb:herobrine" && damagingEntity.hasTag("hit")) removeHerobrine(damagingEntity);

    // Verifica se quem bateu é o JOGADOR
    if (damagingEntity.typeId === "minecraft:player") {
        if (entitiesList[hitEntity.typeId]) {
            if (Utils.randomNumber(1, 25) === 1) {
                const replacementID = entitiesList[hitEntity.typeId];
                const spawnedEntity = hitEntity.dimension.spawnEntity(replacementID, hitEntity.location);

                spawnedEntity.setRotation(hitEntity.getRotation());

                if (hitEntity.hasComponent(EntityComponentTypes.Color)) {
                    const colorComp = hitEntity.getComponent(EntityComponentTypes.Color);
                    const spawnedColor = spawnedEntity.getComponent(EntityComponentTypes.Color);
                    spawnedColor.value = colorComp.value;
                };

                if (hitEntity.nameTag) spawnedEntity.nameTag = hitEntity.nameTag;

                hitEntity.remove();
            }
        }
    }
});

world.afterEvents.playerDimensionChange.subscribe(event => {
    const { player, toDimension } = event;
    let addonData = DynamicManager.fetch(ADDON_SETTINGS_ID);
    if (Utils.getPlayerPerID(addonData.targetID).name === player.name) {
        addonData.targetDimension = toDimension;
    }
});

system.runInterval(() => {

    // Pega as principais variaveis do Herobrine
    let addonData = DynamicManager.fetch(ADDON_SETTINGS_ID);
    let timerData = DynamicManager.fetch(GLOBAL_TIMER_ID);
    const players = world.getAllPlayers();

    // Se nenhum dos Dynamic existir ele trava nessa linha.
    if (!addonData || !timerData) {
        players.forEach(player => {
            if (!player.hasTag("dev")) return;
            player.onScreenDisplay.setActionBar(`§cDynamics não foram criados!`)
        })
        return;
    };

    const { timerSettings } = addonData;
    const actualEvent = addonData?.eventsPassList[0] || null;

    // Configurações das luas de sangue.
    if (!addonData?.totemEnable || !addonData?.bloodMoon) {
        if (bloodMoonPhases.includes(world.getMoonPhase())) {
            world.setAbsoluteTime(world.getAbsoluteTime() + 24000);
        }
    };

    world.getDimension(addonData.targetDimension?.id).getEntities().forEach(entity => {
        if (HEROBRINE_IDS.includes(entity.typeId)) {
            const ridingComponent = entity.getComponent(EntityComponentTypes.Riding);
            if (ridingComponent?.isValid) {
                const rideableComponent = ridingComponent.entityRidingOn.getComponent(EntityComponentTypes.Rideable);
                rideableComponent.ejectRider(entity)
            }
        }
        if (addonData?.bloodMoonEvent) {
            if (entity.hasComponent(EntityComponentTypes.TypeFamily)) {
                const familyComponent = entity.getComponent(EntityComponentTypes.TypeFamily);
                const denyEntities = ["minecraft:creeper"];
                if (familyComponent.getTypeFamilies().includes("monster") && !denyEntities.includes(entity.typeId)) {
                    entity.addEffect("resistance", 5, { amplifier: 2 });
                }
            }
        }
    });

    if (addonData?.bloodMoon) {
        if (bloodMoonPhases.includes(world.getMoonPhase()) && world.getTimeOfDay() >= 13000 && world.getTimeOfDay() < 23000) {
            addonData.bloodMoonEvent = true;
        } else {
            addonData.bloodMoonEvent = false;
        }
    };

    // Tempo de sicronização do timer com o tempo do jogo de 1 segundo
    if (timerData.subtimer === MINECRAFT_TICK && addonData.totemEnable) {
        timerSettings.eventTime = timerSettings.eventTime > 0 ? timerSettings.eventTime -= 1 : 0;
    };

    // Reset do Herobrine quando chega em 0.
    if (timerSettings.eventTime === 0) {
        if (timerData.subtimer === MINECRAFT_TICK) {
            addonData.targetID = Utils.shuffleArray(players)[0]?.id;
            timerSettings.nextEventTime = timerSettings.nextEventTime > 0 ? --timerSettings.nextEventTime : 0;
        };
        world.getDimension(addonData.targetDimension?.id).getEntities().forEach(entity => {
            if (HEROBRINE_IDS.includes(entity.typeId)) {
                removeHerobrine(entity);
            }
        })
    };

    const playerTarget = Utils.getPlayerPerID(addonData.targetID);

    if (timerSettings.nextEventTime <= 0 && addonData.totemEnable && timerSettings.eventTime <= 0) {

        const eventsActive = [];

        // Selecionador de Evento
        while (eventsActive.length === 0) {
            for (let [eventId, event] of Object.entries(addonData.eventsId)) {
                if (event.active) {
                    if (addonData.eventsPassList.includes(eventId)) continue;

                    // Verifica se o dia do inicio é maior que o dia atual
                    if (addonData.initialDay > world.getDay()) addonData.initialDay = world.getDay();

                    // Verifica se o dia atual já permite o evento
                    const currentDay = world.getDay();
                    const eventDay = addonData.initialDay + event.dayUnlock;

                    if (currentDay >= eventDay) {
                        // Adiciona ao array de eventos ativos com base na probabilidade
                        if (Math.random() < event.probability) {
                            eventsActive.push({ ...event, id: eventId });
                        }
                    }
                }
            }
        };

        const selectedEvent = eventsActive.length > 0 ? eventsActive[Utils.randomNumber(0, eventsActive.length - 1)] : undefined;

        if (selectedEvent && playerTarget) {

            const eventsList = new eventsTriggerList(playerTarget, selectedEvent.id);
            const eventTimes = selectedEvent.eventTime;

            addonData.eventsPassList.unshift(selectedEvent.id);

            eventsList[selectedEvent.trigger]();

            addonData.timerSettings.eventTime = eventTimes[Utils.randomNumber(0, eventTimes.length - 1)];
        };

        addonData.timerSettings.nextEventTime = timerSettings.nextEventTimeDefault[Utils.randomNumber(0, timerSettings.nextEventTimeDefault.length - 1)];
    };

    // Limpa o cache.
    if (addonData.eventsPassList.length > addonData.eventsCacheSize) {
        addonData.eventsPassList.pop();
    };

    // Usa o sistema de eventos em Loop (só executa se houver evento ativo E o timer ainda está rodando)
    if (actualEvent && addonData.eventsId[actualEvent]?.triggerLoop !== null) {
        try {
            const eventLoop = new eventsTriggerLoop(Utils.getPlayerPerID(addonData.targetID));
            eventLoop[addonData.eventsId[actualEvent].triggerLoop]();
        } catch { }
    };

    // Atualiza o timer global
    if (addonData?.bloodMoonEvent) {
        timerData.subtimer = timerData.subtimer < MINECRAFT_TICK ? timerData.subtimer += 2 : 0;
    } else {
        timerData.subtimer = timerData.subtimer < MINECRAFT_TICK ? timerData.subtimer += 1 : 0;
    }

    players.forEach(player => {
        if (!deferredWarning && addonData.fogDistance > 0 && player.graphicsMode === "Deferred" && player.playerPermissionLevel === 2) {
            player.sendMessage({ translate: "warning.deferredSupport" });
            deferredWarning = true;
        }
        if (addonData.fogDistance > 0 && addonData?.totemEnable) {
            player.runCommand(`fog @s push hrb:fog_herobrine_${addonData.fogDistance} fog`)
        } else {
            player.runCommand(`fog @s remove fog`)

        }

        if (player.hasTag("dev")) {
            if (player.isSleeping && addonData?.bloodMoonEvent) {
                player.applyDamage(0.0001)
            };
            player.onScreenDisplay.setActionBar(
                `§bSubtimer: §f${timerData.subtimer} / ${MINECRAFT_TICK}\n` +
                `§bAlvo: §f${playerTarget?.name ?? "Nenhum"}\n` +
                `§bDia Inicial: §f${addonData.initialDay}\n` +
                `§bDimensão: §f${addonData.targetDimension.id}\n` +
                `§bEvento Atual: §f${actualEvent?.replace("event_", "").toUpperCase() || "Nenhum"}\n` +
                `§bTotem: §f${addonData.totemEnable ? "Sim" : "Não"}\n` +
                `§bEventTime: §f${timerSettings.eventTime}s\n` +
                `§bNextEventTime: §f${timerSettings.nextEventTime}s\n` +
                `§bCache: §f${addonData.eventsPassList
                    .map(obj => obj.replace("event_", "").toUpperCase())
                    .join(", ")}\n`
            );
        }
    });

    // Armazena as novas informações.
    DynamicManager.write(GLOBAL_TIMER_ID, timerData);
    DynamicManager.write(ADDON_SETTINGS_ID, addonData);
});

export function removeHerobrine(entity) {
    try {
        const addonData = DynamicManager.fetch(ADDON_SETTINGS_ID);
        if (HEROBRINE_IDS.includes(entity.typeId)) {
            if (addonData.VFX) herobrineVFX(entity);
            entity.remove();
        }
    } catch { }
}

export function herobrineVFX(entity, id = "minecraft:ice_evaporation_emitter") {
    const step = 0.1;
    const minHeight = -0.6;
    const maxHeight = 0.85;
    const radius = 0.70;
    const particles = 10;

    for (let height = minHeight; height < maxHeight; height += step) {
        VFX(entity, id, radius, particles, height);
    }
}

export function VFX(entity, particleID, radius, maxParticles = 60, yFIX = 0) {
    const Dimension = world.getDimension(entity.dimension.id)
    const clamp = (value, min, max) => Math.max(min, Math.min(value, max));
    const { x: centerX, y: centerY, z: centerZ } = entity.location;
    const particleCount = Math.min(maxParticles, Math.floor(360 / radius));

    for (let i = 0; i < particleCount; i++) {
        const theta = Math.random() * 2 * Math.PI;
        const phi = Math.acos(2 * Math.random() - 1);

        const distance = radius * Math.random() * 0.5;

        const particleX = centerX + distance * Math.sin(phi) * Math.cos(theta) - 0.5;
        const particleY = clamp(centerY + distance * Math.cos(phi) + yFIX, -64, 320);
        const particleZ = centerZ + distance * Math.sin(phi) * Math.sin(theta) - 0.5;

        Dimension.spawnParticle(particleID, { x: particleX, y: particleY, z: particleZ });
    }
}