import { world } from "@minecraft/server";
import { totemsArrayList } from "./totemsArray";
import { DynamicManager } from "../API/ObsidianAPI";
import { ADDON_SETTINGS_ID } from "../eventFormat";

world.afterEvents.itemStartUseOn.subscribe(event => {
    const { source, itemStack, block, blockFace } = event;
    const dimension = world.getDimension(source.dimension.id);
    const addonData = DynamicManager.fetch(ADDON_SETTINGS_ID);

    if (!itemStack || addonData?.totemEnable) return;

    let structurePass = false;

    totemsArrayList.forEach((totemData) => {
        if (structurePass) return;

        const checker = totemData[0].itemUse === itemStack.typeId && totemData[0].blockFace === blockFace;
        let passBlocks = 0;

        if (checker) {
            totemData.slice(1).forEach((blocksData) => {
                const { location } = block;
                const blockLocation = dimension.getBlock({
                    x: location.x + blocksData.location.x,
                    y: location.y + blocksData.location.y,
                    z: location.z + blocksData.location.z
                });

                let requiredType = blocksData.typeId;
                let mode = blocksData.matchMode || "exact"; // padrão = exact

                let blockOk = false;

                if (mode === "anySolid") {
                    blockOk = blockLocation && blockLocation.typeId !== "minecraft:air";
                }
                else if (mode === "optional") {
                    blockOk = true; // não é obrigatório
                }
                else {
                    // exact (ou array de blocos)
                    if (Array.isArray(requiredType)) {
                        blockOk = requiredType.includes(blockLocation.typeId);
                    } else {
                        blockOk = blockLocation.typeId === requiredType;
                    }
                }

                if (blockOk) passBlocks++;
                else if (mode !== "optional") {
                    // Se não passou e não é opcional, cancela
                    passBlocks = -999;
                }
            });

            if (passBlocks > 0 && passBlocks === totemData.length - 1) {
                // Acionamento
                totemTrigger(dimension, event);
                structurePass = true;
            }
        }
    });
});

function totemTrigger(dimension, event) {
    const { block } = event;
    const addonData = DynamicManager.fetch(ADDON_SETTINGS_ID);

    world.sendMessage({ rawtext: [{ text: "§e" }, { translate: "multiplayer.player.joined", with: ["Herobrine"] }] });

    DynamicManager.write(ADDON_SETTINGS_ID, {
        ...addonData,
        totemEnable: true,
        initialDay: world.getDay(),
        timerSettings: { ...addonData.timerSettings, eventTime: 2 }
    });

    dimension.spawnEntity("minecraft:lightning_bolt", { ...block.location, y: block.location.y + 1 });
    dimension.spawnEntity("hrb:herobrine_stopped", { ...block.bottomCenter(), y: block.location.y + 1 });
}