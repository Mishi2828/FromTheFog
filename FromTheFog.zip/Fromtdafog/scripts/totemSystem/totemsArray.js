export const totemsArrayList = [
    // Totem 1 e 2 (mesclados: bloco do centro pode ser "mossy_cobblestone" OU "gold_block")
    [
        { itemUse: "minecraft:flint_and_steel", blockFace: "Up" },

        { typeId: "minecraft:netherrack", location: { x: 0, y: 0, z: 0 }, matchMode: "exact" },

        { typeId: "minecraft:gold_block", location: { x: 1, y: -1, z: 1 } },
        { typeId: "minecraft:gold_block", location: { x: 1, y: -1, z: 0 } },
        { typeId: "minecraft:gold_block", location: { x: 1, y: -1, z: -1 } },

        { typeId: "minecraft:gold_block", location: { x: 0, y: -1, z: 1 } },
        { typeId: ["minecraft:mossy_cobblestone", "minecraft:gold_block"], location: { x: 0, y: -1, z: 0 } },
        { typeId: "minecraft:gold_block", location: { x: 0, y: -1, z: -1 } },

        { typeId: "minecraft:gold_block", location: { x: -1, y: -1, z: 1 } },
        { typeId: "minecraft:gold_block", location: { x: -1, y: -1, z: 0 } },
        { typeId: "minecraft:gold_block", location: { x: -1, y: -1, z: -1 } },

        { typeId: "minecraft:redstone_torch", location: { x: 1, y: 0, z: 0 }, matchMode: "optional" },
        { typeId: "minecraft:redstone_torch", location: { x: 0, y: 0, z: 1 }, matchMode: "optional" },
        { typeId: "minecraft:redstone_torch", location: { x: 0, y: 0, z: -1 }, matchMode: "optional" },
        { typeId: "minecraft:redstone_torch", location: { x: -1, y: 0, z: 0 }, matchMode: "optional" },
    ],

    // Totem 3 (coluna vertical)
    [
        { itemUse: "minecraft:flint_and_steel", blockFace: "Up" },

        { typeId: "minecraft:netherrack", location: { x: 0, y: 0, z: 0 }, matchMode: "exact" },
        { typeId: "minecraft:netherrack", location: { x: 0, y: -1, z: 0 }, matchMode: "exact" },

        { typeId: "minecraft:gold_block", location: { x: 0, y: -2, z: 0 } },
        { typeId: "minecraft:gold_block", location: { x: 0, y: -3, z: 0 } },
    ]
];



/*
  === Guia dos campos do Totem ===

  itemUse   → item necessário para ativar o totem (ex.: "minecraft:flint_and_steel")
  blockFace → face do bloco onde o item deve ser usado (Up, Down, North, etc.)

  typeId    → tipo do bloco que faz parte da estrutura
               - pode ser string: "minecraft:gold_block"
               - ou array de strings: ["minecraft:mossy_cobblestone", "minecraft:gold_block"] para aceitar múltiplos tipos

  location  → posição relativa ao bloco clicado (x, y, z)

  matchMode → modo de validação do bloco (opcional, default = "exact")
               - "exact"    → o bloco deve ser exatamente do tipo typeId
               - "anySolid" → aceita qualquer bloco sólido (não ar)
               - "optional" → bloco pode ou não estar presente (não quebra a detecção)
*/