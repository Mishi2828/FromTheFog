import { CommandPermissionLevel, system } from "@minecraft/server";
import { GUI_mainMenu } from "./components/herobrineSettings_component";

const commands = [
    {
        name: "hrb:herobrine",
        description: "Comandos relacionados ao Herobrine.",
        permissionLevel: CommandPermissionLevel.GameDirectors
    }
];

system.beforeEvents.startup.subscribe((event) => {
    const registry = event.customCommandRegistry;
    for (const cmd of commands) {
        registry.registerCommand(cmd, (origin, params) => {
            system.run(() => {
                commandExec(cmd.name, origin, params);
            })
        });
    }
});

function commandExec(commandName, origin, params) {
    GUI_mainMenu(origin);
}