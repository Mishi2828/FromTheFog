import { CHUNK_SIZE } from "../ObsidianAPI";

export function getChunkInfo(position) {
    const size = CHUNK_SIZE;

    // ===== Chunk global =====
    const chunk = {
        x: Math.floor(position.x / size),
        y: Math.floor(position.y / size),
        z: Math.floor(position.z / size),
    };

    // ===== Posição local dentro do chunk (arredondada para int) =====
    const local = {
        x: Math.floor(((position.x % size) + size) % size),
        y: Math.floor(((position.y % size) + size) % size),
        z: Math.floor(((position.z % size) + size) % size),
    };

    // ===== Distâncias das bordas (X/Z) =====
    const distLeft = local.x;
    const distRight = size - 1 - local.x;
    const distFront = local.z;
    const distBack = size - 1 - local.z;

    const zeroXZ = [distLeft, distRight, distFront, distBack].filter(d => d === 0).length;

    const isCorner = zeroXZ >= 2;
    const isEdge = zeroXZ === 1;

    // ===== Centro 2x2 =====
    const mid1 = size / 2 - 1;
    const mid2 = size / 2;
    const centerBlocks = [
        { x: mid1, z: mid1 },
        { x: mid1, z: mid2 },
        { x: mid2, z: mid1 },
        { x: mid2, z: mid2 }
    ];
    const isCenter = centerBlocks.some(cb => cb.x === local.x && cb.z === local.z);

    // ===== Tipo de posição =====
    let playerPositionType = "middle";
    if (isCorner) playerPositionType = "corner";
    else if (isEdge) playerPositionType = "edge";
    else if (isCenter) playerPositionType = "center";

    return {
        chunk,
        local,
        playerPositionType,
        isCorner,
        isEdge,
        isCenter,
        centerBlocks
    };
}

// Converte posição local do chunk para coordenadas globais
export function localToWorld(chunk, local, absoluteY = null) {
    return {
        x: chunk.x * CHUNK_SIZE + local.x,
        y: absoluteY !== null ? absoluteY : chunk.y * CHUNK_SIZE + local.y,
        z: chunk.z * CHUNK_SIZE + local.z
    };
}

// Converte coordenadas globais para chunk + posição local
export function worldToLocal(worldPos) {
    const info = getChunkInfo(worldPos);
    return { chunk: info.chunk, local: info.local };
}