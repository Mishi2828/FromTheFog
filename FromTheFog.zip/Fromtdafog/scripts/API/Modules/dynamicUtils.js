import { world } from "@minecraft/server";

export function fetch(name) {
    try {
        const dynamicProperty = world.getDynamicProperty(name);
        return JSON.parse(dynamicProperty);
    } catch {
        return undefined;
    }
}

export function write(name, input) {
    try {
        if (input === undefined || input === null) {
            world.setDynamicProperty(name, undefined);
        } else {
            world.setDynamicProperty(name, JSON.stringify(input));
        }
        return true;
    } catch (error) {
        console.error(`Erro ao escrever propriedade dinâmica '${name}':`, error);
        return false;
    }
}

export function update(dynamicName, structureConfig = null) {
    try {
        let dynamicData = fetch(dynamicName);
        if (dynamicData == undefined || dynamicData == null || dynamicData == "") {
            const writeSuccess = write(dynamicName, structureConfig);
            return writeSuccess ? structureConfig : undefined;
        }
        return dynamicData;
    } catch (error) {
        console.error(`Erro inesperado em '${dynamicName}':`, error);
        return write(dynamicName, structureConfig) ? structureConfig : undefined;
    }
}

export function findAll() {
    const dynamicsList = [];
    world.getDynamicPropertyIds().forEach(dynamic_ID => {
        dynamicsList.push({ id: dynamic_ID, data: fetch(dynamic_ID) });
    });
    return dynamicsList;
}