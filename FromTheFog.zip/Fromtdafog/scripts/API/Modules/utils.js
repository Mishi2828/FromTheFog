import { world } from "@minecraft/server";

/**
 * Gera um número aleatório entre min e max.
 * @param {number} min - Valor mínimo.
 * @param {number} max - Valor máximo.
 * @param {boolean} [round=true] - Se deve arredondar o resultado.
 * @returns {number} Número aleatório.
 */
export function randomNumber(min, max, round = true) {
    if (min > max) return NaN;
    const value = min + Math.random() * (max - min);
    return round ? (value + 0.5 | 0) : value;
}

/**
 * Busca um jogador pelo seu ID único.
 * @param {string} id - ID do jogador.
 * @returns {import("@minecraft/server").Player | undefined} O jogador encontrado ou undefined.
 */
export function getPlayerPerID(id) {
    return world.getAllPlayers().find(player => player.id === id) ?? undefined;
}

/**
 * Faz uma comparação profunda entre dois objetos.
 * @param {Object} obj1 - Primeiro objeto.
 * @param {Object} obj2 - Segundo objeto.
 * @param {Object} [options] - Opções adicionais.
 * @param {string[]} [options.ignoreKeys=[]] - Lista de chaves a ignorar na comparação.
 * @returns {boolean} True se os objetos forem iguais.
 */
export function deepCompare(obj1, obj2, options = {}) {
    const { ignoreKeys = [] } = options;

    function deepCompare(a, b) {
        if (typeof a !== typeof b) return false;

        if (a === null || b === null || typeof a !== "object") {
            return a === b;
        }

        if (Array.isArray(a)) {
            if (!Array.isArray(b) || a.length !== b.length) return false;
            for (let i = 0; i < a.length; i++) {
                if (!deepCompare(a[i], b[i])) return false;
            }
            return true;
        }

        const keysA = Object.keys(a).filter(k => !ignoreKeys.includes(k));
        const keysB = Object.keys(b).filter(k => !ignoreKeys.includes(k));

        if (keysA.length !== keysB.length) return false;

        for (let key of keysA) {
            if (!deepCompare(a[key], b[key])) return false;
        }

        return true;
    }

    return deepCompare(obj1, obj2);
}

/**
 * Calcula a rotação em yaw (graus) de um ponto em direção a outro.
 * @param {{x:number,y:number,z:number}} a_location - Localização de origem.
 * @param {{x:number,y:number,z:number}} b_location - Localização alvo.
 * @returns {number} Ângulo em graus.
 */
export function rotationToTarget(a_location, b_location) {
    const dx = a_location.x - b_location.x;
    const dz = a_location.z - b_location.z;
    const yaw = Math.atan2(dz, dx) * (180 / Math.PI) - 90;
    return yaw;
}

/**
 * Converte um ângulo para rotação válida de placa (0–15).
 * @param {number} targetAngle - Ângulo alvo em graus.
 * @param {boolean} [invertDirection=false] - Se deve inverter a direção.
 * @returns {number} Valor da rotação da placa.
 */
export function calculateSignRotation(targetAngle, invertDirection) {
    let angle = (targetAngle % 360 + 360) % 360;
    let signRotation = Math.floor(angle / 22.5 + 0.5) % 16;
    if (invertDirection) {
        signRotation = (signRotation + 8) % 16;
    }
    return signRotation;
}

/**
 * Calcula a distância entre dois vetores.
 * @param {{x:number,y:number,z:number}} vec1 - Ponto 1.
 * @param {{x:number,y:number,z:number}} vec2 - Ponto 2.
 * @param {number} [decimals=2] - Casas decimais no resultado.
 * @returns {number|null} Distância ou null se inválido.
 */
export function calculateDistance(vec1, vec2, decimals = 2) {
    if (!vec1 || !vec2) return null;
    const dx = (vec1.x ?? 0) - (vec2.x ?? 0);
    const dy = (vec1.y ?? 0) - (vec2.y ?? 0);
    const dz = (vec1.z ?? 0) - (vec2.z ?? 0);
    const distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
    return Number(distance.toFixed(decimals));
}

/**
 * Embaralha os elementos de um array.
 * @param {any[]} array - Array a ser embaralhado.
 * @returns {any[]} Novo array embaralhado.
 */
export function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

/**
 * Retorna os itens do inventário de uma entidade/bloco.
 * @param {import("@minecraft/server").Entity} objectID - Entidade ou Bloco que possui inventário.
 * @param {string|null} [emptySlotTypeId=null] - Valor a atribuir para slots vazios (se desejado).
 * @returns {{item: any, slot: number}[] | void} Lista de itens e slots.
 */
export function getItemsInInventory(objectID, emptySlotTypeId = null) {
    const hasComponent = objectID.hasComponent("minecraft:inventory");
    if (hasComponent) {
        const inventoryComponent = objectID.getComponent("minecraft:inventory");
        const itemsArray = [];
        for (let slotIndex = 0; slotIndex < inventoryComponent.inventorySize; slotIndex++) {
            const itemInSlot = inventoryComponent.container.getItem(slotIndex);
            const paramEmptySlot = itemInSlot?.typeId ? itemInSlot : emptySlotTypeId;
            if (paramEmptySlot !== null) {
                itemsArray.push({ item: paramEmptySlot, slot: slotIndex });
            }
        }
        return itemsArray;
    } else {
        console.warn("[ERROR] O objeto não tem componente 'minecraft:inventory'");
    }
}

/**
 * Escolhe um elemento de um array com base em pesos.
 * 
 * @param {Array} items - Lista de objetos com pesos.
 * @param {string} [weightKey='weight'] - Nome da propriedade que contém o peso.
 * @param {function} [rng=Math.random] - Função aleatória opcional (para seed, se quiser).
 * @returns {*} - O item escolhido.
 */
export function weightedChoice(items, weightKey = 'weight', rng = Math.random) {
    if (!Array.isArray(items) || items.length === 0) return undefined;

    // sanitiza e transforma os pesos em números >= 0
    const sanitized = items.map(item => {
        const raw = item[weightKey];
        const num = Number(raw);
        const weight = Number.isFinite(num) && num > 0 ? num : 0;
        return { item, weight };
    });

    const total = sanitized.reduce((s, e) => s + e.weight, 0);
    if (total === 0) return undefined;

    let r = rng() * total;
    for (const { item, weight } of sanitized) {
        if (r < weight) return item;
        r -= weight;
    }
    return sanitized[sanitized.length - 1].item;
}

/**
 * Gera uma matriz 2D de Perlin Noise
 * @param {number} width - largura da matriz
 * @param {number} depth - profundidade da matriz
 * @param {object} options - opções de Perlin
 * @param {number} options.seed - semente do noise
 * @param {number} options.scale - escala do noise
 * @param {number} options.octaves - camadas
 * @param {number} options.persistence - persistência
 * @param {number} options.min - valor mínimo da altura
 * @param {number} options.max - valor máximo da altura
 * @param {boolean} options.round - se true retorna inteiros
 * @returns {number[][]} matriz [depth][width] com valores
 */
export function perlinNoise(width, depth, {
    seed = 0,
    scale = 0.1,
    octaves = 1,
    persistence = 0.5,
    min = 0,
    max = 1,
    round = false
} = {}) {

    // Função auxiliar: calcula Perlin para um ponto
    const perlin = (x, y) => {
        const random2D = (ix, iy) => {
            const n = Math.sin(ix * 127.1 + iy * 311.7 + seed * 1013.9) * 43758.5453;
            return n - Math.floor(n);
        };
        const gradient = (ix, iy) => {
            const r = random2D(ix, iy) * Math.PI * 2;
            return { x: Math.cos(r), y: Math.sin(r) };
        };
        const dotGridGradient = (ix, iy, x, y) => {
            const g = gradient(ix, iy);
            const dx = x - ix;
            const dy = y - iy;
            return dx * g.x + dy * g.y;
        };
        const fade = t => t * t * t * (t * (t * 6 - 15) + 10);
        const lerp = (a, b, t) => a + t * (b - a);

        let total = 0;
        let frequency = scale;
        let amplitude = 1;
        let maxValue = 0;

        for (let i = 0; i < octaves; i++) {
            const nx = x * frequency;
            const ny = y * frequency;

            const x0 = Math.floor(nx);
            const x1 = x0 + 1;
            const y0 = Math.floor(ny);
            const y1 = y0 + 1;

            const sx = fade(nx - x0);
            const sy = fade(ny - y0);

            const n0 = dotGridGradient(x0, y0, nx, ny);
            const n1 = dotGridGradient(x1, y0, nx, ny);
            const ix0 = lerp(n0, n1, sx);

            const n2 = dotGridGradient(x0, y1, nx, ny);
            const n3 = dotGridGradient(x1, y1, nx, ny);
            const ix1 = lerp(n2, n3, sx);

            const value = lerp(ix0, ix1, sy);

            total += value * amplitude;
            maxValue += amplitude;

            amplitude *= persistence;
            frequency *= 2;
        }

        let normalized = total / maxValue * 0.5 + 0.5; // 0..1
        let scaled = min + normalized * (max - min);
        if (round) scaled = Math.round(scaled);

        return scaled;
    };

    // Gera a matriz
    const matrix = [];
    for (let z = 0; z < depth; z++) {
        const row = [];
        for (let x = 0; x < width; x++) {
            row.push(perlin(x, z));
        }
        matrix.push(row);
    }

    return matrix;
}