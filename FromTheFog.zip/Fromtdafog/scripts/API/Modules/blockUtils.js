import { world, system, BlockComponentTypes } from "@minecraft/server";
import { calculateSignRotation, randomNumber } from "./utils";

/**
 * Varre uma área entre dois pontos e retorna os blocos que passam pelos filtros.
 * @param {object} options
 * @param {{x:number,y:number,z:number}} options.from - Ponto inicial da área
 * @param {{x:number,y:number,z:number}} options.to - Ponto final da área
 * @param {Dimension} [options.dimension] - Dimensão (padrão overworld)
 * @param {object} [options.filter] - Filtros opcionais (includeTypes, excludeTypes, includeTags, custom)
 * @param {boolean} [options.includeAir=false] - Se deve incluir blocos de ar
 * @returns {Block[]} Lista de blocos que passam pelos filtros
 */
export function scanArea({
    from,
    to,
    dimension = world.getDimension("overworld"),
    filter = {},
    includeAir = false
}) {
    if (!from || !to) return {};

    // ====== Define limites da área ======
    const minX = Math.min(from.x, to.x);
    const maxX = Math.max(from.x, to.x);
    const minY = Math.min(from.y, to.y);
    const maxY = Math.max(from.y, to.y);
    const minZ = Math.min(from.z, to.z);
    const maxZ = Math.max(from.z, to.z);

    const result = [];

    // ====== Varre cada bloco na área ======
    for (let x = minX; x <= maxX; x++) {
        for (let y = minY; y <= maxY; y++) {
            for (let z = minZ; z <= maxZ; z++) {
                try {
                    const block = dimension.getBlock({ x, y, z });
                    if (!block) continue;

                    // ====== Ignora blocos de ar, se não permitido ======
                    if (!includeAir && block.typeId === "minecraft:air") continue;

                    // ====== Filtros básicos ======
                    if (filter.includeTypes && !filter.includeTypes.includes(block.typeId)) continue;
                    if (filter.excludeTypes && filter.excludeTypes.includes(block.typeId)) continue;

                    // ====== Filtro por tags ======
                    if (filter.includeTags) {
                        const blockTags = block.getTags?.() ?? [];
                        if (!filter.includeTags.every(tag => blockTags.includes(tag))) continue;
                    }

                    // ====== Filtro customizado ======
                    if (filter.custom && !filter.custom(block)) continue;

                    // ====== Adiciona bloco válido ao resultado ======
                    result.push(block)
                } catch (e) {
                    // Ignora erros ao acessar o bloco
                }
            }
        }
    }

    return result;
}

/**
 * Preenche uma área com blocos específicos de forma simples e eficiente.
 * 
 * @param {object} options - Opções de configuração
 * @param {{x:number,y:number,z:number}} options.from - Ponto inicial da área
 * @param {{x:number,y:number,z:number}} options.to - Ponto final da área
 * @param {Dimension} [options.dimension] - Dimensão onde executar (padrão: overworld)
 * @param {Array<{id:string, probability:number}>} options.blocks - Lista de blocos com probabilidades
 * @param {boolean} [options.onlyAir=false] - Se true, substitui apenas blocos de ar
 * @param {object} [options.filter] - Filtros opcionais para seleção de blocos
 * @param {string[]} [options.filter.includeTypes] - Apenas modifica estes tipos de blocos
 * @param {string[]} [options.filter.excludeTypes] - Não modifica estes tipos de blocos
 * 
 * @returns {Block[]} Lista de blocos que foram modificados
 * @example
 * // Preenche apenas onde tem ar com terra e grama
 * fillBlocks({
 *   from: {x: -5, y: 60, z: -5},
 *   to: {x: 5, y: 65, z: 5},
 *   blocks: [
 *     {id: "minecraft:dirt", probability: 0.7},
 *     {id: "minecraft:grass_block", probability: 0.3}
 *   ],
 *   onlyAir: true
 * });
 */
export function fillBlocks({
    from,
    to,
    dimension = world.getDimension("minecraft:overworld"),
    blocks = [{ id: "minecraft:stone", weight: 1 }],
    onlyAir = false,
    filter = {}
}) {
    // Validação básica
    if (!from || !to) {
        return [];
    }

    // Define os limites da área
    const minX = Math.min(from.x, to.x);
    const maxX = Math.max(from.x, to.x);
    const minY = Math.min(from.y, to.y);
    const maxY = Math.max(from.y, to.y);
    const minZ = Math.min(from.z, to.z);
    const maxZ = Math.max(from.z, to.z);

    // Prepara sistema de probabilidade
    const weightedBlocks = [];
    let totalWeight = 0;

    for (const block of blocks) {
        const weight = block.weight ?? 1;
        totalWeight += weight;
        weightedBlocks.push({
            id: block.id,
            cumulative: totalWeight
        });
    }

    // Função para escolher bloco aleatório baseado em probabilidade
    function pickRandomBlock() {
        const random = Math.random() * totalWeight;
        for (const block of weightedBlocks) {
            if (random <= block.cumulative) {
                return block.id;
            }
        }
        return weightedBlocks[weightedBlocks.length - 1].id;
    }

    const modifiedBlocks = [];

    // Percorre todos os blocos na área
    for (let x = minX; x <= maxX; x++) {
        for (let y = minY; y <= maxY; y++) {
            for (let z = minZ; z <= maxZ; z++) {
                try {
                    const block = dimension.getBlock({ x, y, z });
                    if (!block) continue;

                    const blockType = block.typeId;

                    // Verifica se deve modificar apenas ar
                    if (onlyAir && blockType !== "minecraft:air") continue;

                    // Aplica filtros se especificados
                    if (filter.includeTypes && !filter.includeTypes.includes(blockType)) continue;
                    if (filter.excludeTypes && filter.excludeTypes.includes(blockType)) continue;

                    // Escolhe e aplica o novo bloco
                    const newBlockId = pickRandomBlock();
                    block.setType(newBlockId);
                    modifiedBlocks.push(block);

                } catch (error) {
                    // Ignora erros silenciosamente e continua
                }
            }
        }
    }

    return modifiedBlocks;
}

/**
 * Varre blocos ao redor de um ponto central com padrões circulares/retangulares e altura vertical.
 * @param {object} options
 * @param {{x:number,y:number,z:number}} options.center - Centro da varredura
 * @param {{height:number,width:number}} options.areaSize - Tamanho da área
 * @param {number} options.innerRadius - Raio interno (para shell circular)
 * @param {boolean} options.circular - Se deve ser circular
 * @param {"both"|"up"|"down"} options.verticalPattern - Direção vertical
 * @param {Dimension} [options.dimension] - Dimensão (padrão overworld)
 * @param {object} [options.filter] - Filtros opcionais
 * @param {boolean} [options.includeAir=false] - Inclui blocos de ar
 * @returns {Block[]} Lista de blocos válidos
 */
export function scanAround({
    center = { x: 0, y: 0, z: 0 },
    areaSize = { height: 5, width: 30 },
    innerRadius = 0,
    circular = false,
    verticalPattern = "both",
    dimension = world.getDimension("overworld"),
    filter = {},
    includeAir = false
}) {
    if (!center) return [];

    const { min: yMin, max: yMax } = dimension.heightRange;
    const centerX = Math.floor(center.x) + 0.5;
    const centerY = Math.floor(center.y);
    const centerZ = Math.floor(center.z) + 0.5;

    const shellThickness = areaSize.width;
    const verticalHalfHeight = areaSize.height;
    const outerRadius = innerRadius + shellThickness;

    const startX = Math.floor(centerX - outerRadius);
    const endX = Math.floor(centerX + outerRadius);
    const startZ = Math.floor(centerZ - outerRadius);
    const endZ = Math.floor(centerZ + outerRadius);
    const startY = Math.max(Math.floor(centerY - verticalHalfHeight), yMin);
    const endY = Math.min(Math.floor(centerY + verticalHalfHeight), yMax);

    const innerSq = innerRadius * innerRadius;
    const outerSq = outerRadius * outerRadius;

    const result = [];

    for (let x = startX; x <= endX; x++) {
        const dx = x + 0.5 - centerX;
        const dxSq = dx * dx;

        for (let z = startZ; z <= endZ; z++) {
            const dz = z + 0.5 - centerZ;
            const dzSq = dz * dz;

            let inZone = false;
            if (circular) {
                const distSq = dxSq + dzSq;
                inZone = innerRadius <= 0 ? distSq <= outerSq : distSq > innerSq && distSq <= outerSq;
            } else {
                const maxDist = Math.max(Math.abs(dx), Math.abs(dz));
                inZone = innerRadius <= 0 ? maxDist <= outerRadius : maxDist > innerRadius && maxDist <= outerRadius;
            }

            if (!inZone) continue;

            for (let y = startY; y <= endY; y++) {
                const yDiff = y - centerY;
                if (verticalPattern === "down" && yDiff > 0) continue;
                if (verticalPattern === "up" && yDiff < 0) continue;

                try {
                    const block = dimension.getBlock({ x, y, z });
                    if (!block) continue;
                    if (!includeAir && block?.isAir) continue;
                    if (filter.includeTypes && !filter.includeTypes.includes(block.typeId)) continue;
                    if (filter.excludeTypes && filter.excludeTypes.includes(block.typeId)) continue;
                    if (filter.includeTags) {
                        const blockTags = block.getTags ? block.getTags() : [];
                        if (!filter.includeTags.every(tag => blockTags.includes(tag))) continue;
                    }
                    if (filter.custom && !filter.custom(block)) continue;

                    // ====== Adiciona bloco válido ======
                    result.push(block);
                } catch (e) {
                    console.warn(`Erro ao obter o bloco em (${x},${y},${z}):`, e);
                }
            }
        }
    }

    return result
}