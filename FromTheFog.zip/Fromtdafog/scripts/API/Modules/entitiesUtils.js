import { world } from "@minecraft/server";
import { scanAround } from "./blockUtils";
import { Utils } from "../ObsidianAPI";

/**
 * Verifica se uma área de spawn é segura com base em blocos e filtros definidos.
 * 
 * @param {Block} block - Bloco base para verificação
 * @param {object} filter - Filtros aplicáveis
 * @returns {boolean} - Verdadeiro se o local for seguro para spawn
 */
function isSafeSpawnArea(block, filter) {
    if (!block) return false;
    if (block.isAir) return false;
    if (filter?.denyLiquid && block.isLiquid) return false;

    const blockAbove1 = block.above(1);
    const blockAbove2 = block.above(2);

    // Verifica se há espaço livre acima
    if (!blockAbove1?.isAir || !blockAbove2?.isAir) return false;

    // Verifica se o bloco está em uma lista de negação
    if (filter?.denyBlocks?.includes(block.typeId)) return false;

    // Verificação customizada do usuário
    if (typeof filter?.custom === "function" && !filter.custom(block)) return false;

    return true;
}

/**
 * Spawn de entidades em uma região ao redor de um ponto central.
 * Varre blocos, aplica filtros e tenta spawnar entidades válidas.
 * 
 * @param {object} options - Opções de spawn
 * @param {{id:string,tags?:string[],weight?:number,count?:number}[]} [options.entities] - Entidades possíveis de spawn com peso para escolha aleatória e contagem opcional
 * @param {{x:number,y:number,z:number}} [options.location] - Centro da varredura
 * @param {Dimension} [options.dimension] - Dimensão onde spawnar (padrão: overworld)
 * @param {{height:number,width:number}} [options.areaSize] - Tamanho da área de varredura
 * @param {number} [options.innerRadius] - Raio interno a ser ignorado
 * @param {boolean} [options.circular] - Se a varredura é circular
 * @param {number} [options.maxTries] - Máximo de tentativas de spawn
 * @param {object} [options.filter] - Filtros aplicáveis
 * @param {string[]} [options.filter.denyBlocks] - Tipos de blocos que não podem ser usados
 * @param {object[]} [options.filter.surfaceFix] - Ajustes de altura para blocos específicos
 * @param {function} [options.filter.custom] - Função customizada para filtrar blocos
 * @param {boolean} [options.filter.denyLiquid] - Impede spawn sobre líquidos
 * 
 * @returns {Entity[]|undefined} - Lista de entidades spawnadas ou undefined se não foi possível
 */
export function spawnEntityInRegion({
    entities = [
        { id: "minecraft:zombie", tags: ["zombie"], weight: 0.5 },
        { id: "minecraft:skeleton", tags: ["skeleton"], weight: 0.5 },
    ],
    location = { x: 0, y: 0, z: 0 },
    dimension = world.getDimension("minecraft:overworld"),
    areaSize = { height: 10, width: 4 },
    innerRadius = 12,
    circular = true,
    maxTries = 512,
    filter = { denyBlocks: [], surfaceFix: [], custom: null, denyLiquid: true },
}) {
    if (!location) return undefined;

    // ====== Varre blocos ao redor ======
    const blocksData = scanAround({
        center: location,
        areaSize,
        innerRadius,
        circular,
        dimension,
        filter: { custom: filter.custom, excludeTypes: filter.denyBlocks },
    });

    if (!blocksData.length) return undefined;

    // Filtra apenas blocos válidos para spawn
    const validBlocks = blocksData.filter(block => isSafeSpawnArea(block, filter));
    if (!validBlocks.length) return undefined;

    const spawnedEntities = [];

    // ====== Escolhe entidade e tenta spawnar ======
    const chosenEntity = Utils.weightedChoice(entities, "weight");
    if (!chosenEntity) return undefined;

    const count = Math.max(1, chosenEntity.count ?? 1);

    for (let i = 0; i < count; i++) {
        const block = Utils.shuffleArray(validBlocks)[0];
        if (!block) continue;

        // Procura base sólida se necessário
        let newLocation = block;
        for (let index = 1; index < 16; index++) {
            const blockBelow = block.below(index);
            const blockChecker = filter.surfaceFix?.some(fix => blockBelow.typeId.includes(fix.typeId));
            if (blockChecker && !blockBelow?.isAir && !blockBelow?.isLiquid) {
                newLocation = blockBelow;
                break;
            }
        }

        // Ajuste de altura
        const surfaceFix = filter.surfaceFix?.find(fix => newLocation.typeId.includes(fix.typeId));
        const basePos = {
            x: newLocation.bottomCenter().x,
            y: newLocation.location.y + (surfaceFix?.fix?.y ?? 1),
            z: newLocation.bottomCenter().z,
        };

        const finalPos = {
            x: basePos.x + (Math.random() - 0.5) * 0.8,
            y: basePos.y,
            z: basePos.z + (Math.random() - 0.5) * 0.8,
        };

        const spawnedEntity = dimension.spawnEntity(chosenEntity.id, finalPos);
        chosenEntity.tags?.forEach(tag => spawnedEntity.addTag(tag));
        spawnedEntities.push(spawnedEntity);
    }

    return spawnedEntities.length ? spawnedEntities : undefined;
}
