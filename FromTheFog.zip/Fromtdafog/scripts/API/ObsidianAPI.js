// ObsidianAPI.js
import * as Utils from "./Modules/utils.js";
import * as Block from "./Modules/blockUtils.js";
import * as Chunk from "./Modules/chunkUtils.js";
import * as Entities from "./Modules/entitiesUtils.js";
import * as DynamicManager from "./Modules/dynamicUtils.js";

export const CHUNK_SIZE = 16;
export const API_VERSION = "0.1.0-alpha";

export class ObsidianAPI {
    static Utils = Utils;
    static Block = Block;
    static Chunk = Chunk;
    static Entities = Entities;
    static DynamicManager = DynamicManager;
}
console.log(`Obsidian API: §e${API_VERSION}§r`);

// Exporta módulos diretamente para destruturação
// Exemplo: import { Utils, DynamicManager } from "API/ObsidianAPI.js"
export { Utils, Block, Chunk, Entities, DynamicManager };
