import { BlockComponentTypes, EntityComponentTypes, system, world } from "@minecraft/server";
import { ObsidianAPI } from "./API/ObsidianAPI";
import { ADDON_SETTINGS_ID, HEROBRINE_IDS } from "./eventFormat";
import { removeHerobrine } from "./index";

const { Utils, Entities, Block, DynamicManager } = ObsidianAPI;

const herobrineCustom = (block) => !block.typeId.includes("leaves") || block.getTags().includes("flower") || JSON.stringify(block.permutation.getAllStates()).includes("flower")

export class eventsTriggerList {
    constructor(target, eventID) {
        this.target = target;
        this.dimension = world.getDimension(target?.dimension.id);
        this.eventId = eventID;
    }

    watching() {
        Entities.spawnEntityInRegion({
            dimension: this.dimension,
            entities: [{ id: "hrb:herobrine_stopped", tags: ["watching"], weight: 1 }],
            location: this.target.location,
            innerRadius: 16,
            areaSize: { height: 3, width: 5 },
            circular: true,
            filter: {
                surfaceFix: surfaceBlockFixList,
                custom: (block) => {
                    return herobrineCustom(block)
                }
            }
        })
    }

    chatMessage() {
        const normalMessageMax = 3;
        const citationMessageMax = 3;

        // Função para criar mensagem
        const createMessage = (type, target = null) => {
            const index = Utils.randomNumber(1, type === "citation" ? citationMessageMax : normalMessageMax);
            return {
                rawtext: [
                    { text: "<" },
                    { translate: "entity.hrb:herobrine.name" },
                    { text: "> " },
                    {
                        translate: `${type === "citation" ? "chat.citationMessage" : "chat.message"}${index}`,
                        with: target ? [target.name] : undefined
                    }
                ]
            };
        };

        // Decide aleatoriamente se a mensagem terá citação ou não
        const type = Utils.randomNumber(0, 1) === 0 ? "normal" : "citation";
        const target = type === "citation" ? this.target : null;

        world.sendMessage(createMessage(type, target));
    }

    ownAnimals() {
        const addonData = DynamicManager.fetch(ADDON_SETTINGS_ID)
        const extraButtons = addonData.eventsId[this.eventId]?.extraButtons
        const entitiesList = {
            "minecraft:chicken": "hrb:chicken",
            "minecraft:villager": extraButtons[0]?.value ? "hrb:villager" : null,
            "minecraft:sheep": "hrb:sheep",
            "minecraft:cow": "hrb:cow",
            "minecraft:pig": "hrb:pig",
            "minecraft:bee": "hrb:bee",
        }
        for (let entityID of Object.keys(entitiesList)) {
            this.dimension.getEntities({ location: this.target.location, maxDistance: 128, type: entityID }).forEach((entity) => {
                if (entitiesList[entityID] !== null) {

                    const entitySpawned = this.dimension.spawnEntity(`${entitiesList[entityID]}`, entity.location, { spawnEvent: entity.hasComponent(EntityComponentTypes.IsBaby) ? "minecraft:entity_born" : "" });
                    entitySpawned.setRotation(entity.getRotation());

                    if (entity.hasComponent(EntityComponentTypes.Color)) {
                        const entityColorComponent = entity.getComponent(EntityComponentTypes.Color);
                        const spawnedColorComponent = entitySpawned.getComponent(EntityComponentTypes.Color);
                        spawnedColorComponent.value = entityColorComponent.value;
                    };

                    if (entity.nameTag) entitySpawned.nameTag = entity.nameTag;

                    entity.remove();
                }
            })
        }
    }

    scarySound() {
        const SOUNDS_MINER_DEEP = [
            "scary.stone_breaking.sound",
        ];
        const SOUNDS_MINER_MID = [
            "scary.dirt_breaking.sound",
        ];
        const SOUNDS_DEFAULT = [
            "ambient.basalt_deltas.mood",
            "ambient.cave",
            "ambient.crimson_forest.mood",
            "ambient.warped_forest.mood"
        ];

        const Y_LEVEL_DEEP_THRESHOLD = 40;
        const Y_LEVEL_MID_THRESHOLD = 90;
        const CHANCE_FOR_DEEP_SOUND = 20;
        const CHANCE_FOR_MID_SOUND = 10;

        const getRandomElement = (array) => array[Utils.randomNumber(0, array.length - 1)];

        const playerY = this.target.location.y;
        let soundToPlay;

        if (playerY < Y_LEVEL_DEEP_THRESHOLD && Utils.randomNumber(1, CHANCE_FOR_DEEP_SOUND) === 1)
            soundToPlay = getRandomElement(SOUNDS_MINER_DEEP);
        else if (playerY < Y_LEVEL_MID_THRESHOLD && Utils.randomNumber(1, CHANCE_FOR_MID_SOUND) === 1)
            soundToPlay = getRandomElement(SOUNDS_MINER_MID);
        else
            soundToPlay = getRandomElement(SOUNDS_DEFAULT);

        if (soundToPlay) this.target.playSound(soundToPlay)
    }

    watchingScare() {
        Entities.spawnEntityInRegion({
            dimension: this.dimension,
            entities: [{ id: "hrb:herobrine_stopped", tags: ["watchingScare"], weight: 1 }],
            location: this.target.location,
            innerRadius: 16,
            areaSize: { height: 3, width: 5 },
            circular: true,
            filter: {
                surfaceFix: surfaceBlockFixList,
                custom: (block) => {
                    return herobrineCustom(block)
                }
            }
        })
    }

    watchingSub() {
        Entities.spawnEntityInRegion({
            dimension: this.dimension,
            entities: [{ id: "hrb:herobrine_stopped", tags: ["watchingSub"], weight: 1 }],
            location: this.target.location,
            innerRadius: 16,
            areaSize: { height: 3, width: 5 },
            circular: true,
            filter: {
                surfaceFix: surfaceBlockFixList,
                custom: (block) => {
                    return herobrineCustom(block)
                }
            }
        })
    }

    sign() {
        if (!this.target) {
            return;
        }

        const denyBlockList_sign = [
            "minecraft:tall_grass", "minecraft:short_grass", "minecraft:large_fern",
            "minecraft:bamboo", "minecraft:reeds", "minecraft:vine",
            "minecraft:rose_bush", "minecraft:peony", "minecraft:crimson_roots",
            "minecraft:crimson_fungus", "minecraft:warped_fungus", "minecraft:brown_mushroom",
            "minecraft:red_mushroom", "minecraft:wildflowers", "minecraft:leaf_litter",
            "minecraft:dandelion", "minecraft:fern", "minecraft:poppy", "minecraft:fire",
            "minecraft:snow_layer"
        ];

        const candidateBlocks = Block.scanAround({
            center: this.target.location,
            areaSize: { width: 7, height: 5 },
            innerRadius: 2,
            dimension: this.dimension,
            circular: true,
            filter: {
                excludeTypes: ["minecraft:sweet_berry_bush"],
                custom: (block) => !block.typeId.includes("_leaves") && !block.isLiquid
            }
        });

        if (candidateBlocks.length === 0) return;

        const validLocations = [];

        // Itera sobre os blocos candidatos para encontrar uma superfície sólida.
        for (const startBlock of candidateBlocks) {
            if (!startBlock || startBlock.isAir) continue;

            let surfaceBlock = null;

            // Desce até 10 blocos para encontrar o primeiro chão que não seja ar, líquido ou vegetação.
            for (let i = 0; i < 16; i++) {
                const current = startBlock.below(i);
                if (!current) break; // Impede crash se o bloco estiver fora de uma área carregada.

                if (!current.isAir && !current.isLiquid && !denyBlockList_sign.includes(current.typeId)) {
                    surfaceBlock = current;
                    break;
                }
            }

            if (!surfaceBlock) continue;

            const placementBlock = surfaceBlock.above();
            if (placementBlock && (placementBlock.isAir || denyBlockList_sign.includes(placementBlock.typeId))) {
                validLocations.push(placementBlock.location);
            }
        }

        if (validLocations.length === 0) return;
        const selectedLocation = Utils.shuffleArray(validLocations)[0];

        this.dimension.setBlockType(selectedLocation, "minecraft:standing_sign");

        const signBlock = this.dimension.getBlock(selectedLocation);

        if (!signBlock || signBlock.typeId !== "minecraft:standing_sign") return;
        const rotation = Utils.calculateSignRotation(Utils.rotationToTarget(this.target.location, selectedLocation));

        signBlock.setPermutation(signBlock.permutation.withState("ground_sign_direction", rotation));

        const normalMessageMax = 3;
        const citationMessageMax = 3;
        const type = Utils.randomNumber(0, 1) === 0 ? "normal" : "citation";
        const index = Utils.randomNumber(1, type === "citation" ? citationMessageMax : normalMessageMax);

        const signText = {
            rawtext: [
                {
                    translate: `${type === "citation" ? "sign.citationMessage" : "sign.message"}${index}`,
                    with: type === "citation" ? [this.target.name ?? ""] : undefined
                }
            ]
        };

        // Garante que o componente da placa existe antes de tentar escrever nele.
        const signComp = signBlock.getComponent(BlockComponentTypes.Sign);
        if (signComp) {
            signComp.setText(signText);
        }
    }

    changeTorches() {
        const blocks = Block.scanAround({
            center: this.target.location,
            areaSize: { width: 30, height: 10 },
            dimension: this.dimension,
            circular: false,
            filter: { includeTypes: ["minecraft:torch"] },
        });

        blocks.forEach(block => {
            const originalPermutation = block.permutation;

            this.dimension.setBlockType(block.location, "minecraft:redstone_torch");
            const blockInLocation = this.dimension.getBlock(block.location);

            blockInLocation.setPermutation(blockInLocation.permutation.withState("torch_facing_direction", originalPermutation.getState("torch_facing_direction")));
        });
    }

    attack() {
        Entities.spawnEntityInRegion({
            dimension: this.dimension,
            entities: [{ id: "hrb:herobrine", tags: ["attack"], weight: 1 }],
            location: this.target.location,
            innerRadius: 5,
            areaSize: { height: 3, width: 5 },
            circular: true,
            filter: {
                surfaceFix: surfaceBlockFixList,
                custom: (block) => {
                    return herobrineCustom(block)
                }
            }
        })
    }

    hitScare() {
        Entities.spawnEntityInRegion({
            dimension: this.dimension,
            entities: [{ id: "hrb:herobrine", tags: ["hit"], weight: 1 }],
            location: this.target.location,
            innerRadius: 5,
            areaSize: { height: 3, width: 5 },
            circular: true,
            filter: {
                surfaceFix: surfaceBlockFixList,
                custom: (block) => {
                    return herobrineCustom(block)
                }
            }
        })
    }

    // FUNCIÓN DE FUEGO DESACTIVADA
    randomFire() {
        return;
    }

    // FUNCIÓN DE CRASH DESACTIVADA
    crashWorld() {
        return;
    }

    // FUNCIÓN DE TÚNEL DESACTIVADA
    tunnel() {
        return;
    }
}


export class eventsTriggerLoop {
    constructor(target) {
        this.target = target;
        this.dimension = world.getDimension(target?.dimension?.id);
    }

    watchingLoop() {
        world.getAllPlayers().forEach(player => {
            player.getEntitiesFromViewDirection({ maxDistance: 312, ignoreBlockCollision: true }).forEach(entitiyData => {
                const { entity } = entitiyData;
                if (!HEROBRINE_IDS.includes(entity.typeId) && !entity) return;
                if (entity.hasTag("watchingSub")) {
                    const RNG = Utils.randomNumber(1, 4)
                    switch (RNG) {
                        case 1:
                            // DESACTIVADO: La invocación de rayos fue comentada.
                            // this.dimension.spawnEntity("minecraft:lightning_bolt", entity.location); 
                            break;
                        case 2:
                            Entities.spawnEntityInRegion({
                                dimension: this.dimension,
                                entities: [{ id: "minecraft:zombie", weight: 1, count: Utils.randomNumber(2, 6) }],
                                location: entity.location,
                                innerRadius: 1,
                                areaSize: { height: 5, width: 2 },
                                circular: true,
                                filter: {
                                    surfaceFix: surfaceBlockFixList,
                                    custom: (block) => herobrineCustom(block)
                                }
                            });
                            break;
                        case 3:
                            break;
                    }
                    removeHerobrine(entity);
                } else if (entity.hasTag("watchingScare")) {
                    try {
                        entity.teleport(this.target.location);
                        system.runTimeout(() => {
                            removeHerobrine(entity);
                            system.runTimeout(() => {
                                this.target.addEffect("blindness", 10 * 20);
                                this.target.addEffect("slowness", 10 * 20);
                            }, 2)
                        }, 5)
                    } catch { }
                } else if (entity.hasTag("watching")) {
                    removeHerobrine(entity);
                }
            })
        })
    }

    attackLoop() {
        const difficultySwordList = {
            "peaceful": "minecraft:wooden_sword",
            "easy": "minecraft:iron_sword",
            "normal": "minecraft:diamond_sword",
            "hard": "minecraft:netherite_sword",
        }
        this.dimension.getEntities({ type: "hrb:herobrine", tags: ["attack"] }).forEach((entity) => {
            const healthComponent = entity.getComponent(EntityComponentTypes.Health);
            if (healthComponent.currentValue < 500 && healthComponent.currentValue >= 200) {
                entity.addEffect("minecraft:strength", 10, { amplifier: 0, showParticles: true });
                entity.addEffect("minecraft:speed", 10, { amplifier: 0, showParticles: true });
                entity.runCommand(`replaceitem entity @s slot.weapon.mainhand 0 ${difficultySwordList[world.getDifficulty()]}`);
            } else if (healthComponent.currentValue < 200 && healthComponent.currentValue > 0) {
                entity.addEffect("minecraft:strength", 10, { amplifier: 1, showParticles: true });
                entity.addEffect("minecraft:speed", 10, { amplifier: 1, showParticles: true });
            }
        });
    }
}

// Listas padrões
const surfaceBlockFixList = [
    { typeId: "minecraft:leaf_litter", fix: { y: 0 } },
    { typeId: "minecraft:short_grass", fix: { y: 0 } },
    { typeId: "minecraft:short_dry_grass", fix: { y: 0 } },
    { typeId: "minecraft:tall_grass", fix: { y: 0 } },
    { typeId: "minecraft:tall_dry_grass", fix: { y: 0 } },
    { typeId: "minecraft:reeds", fix: { y: 0 } },
    { typeId: "minecraft:short_dry_grass", fix: { y: 0 } },
    { typeId: "minecraft:wildflowers", fix: { y: 0 } },
    { typeId: "minecraft:snow_layer", fix: { y: 0 } },

    // Outros
    { typeId: "fern", fix: { y: 0 } },
    { typeId: "bush", fix: { y: 0 } },
    { typeId: "_slab", fix: { y: -0.2 } },
    { typeId: "_pressure_plate", fix: { y: 0 } },
    { typeId: "standing_sign", fix: { y: 0 } },

    // Crops
    { typeId: "minecraft:wheat", fix: { y: 0 } },
    { typeId: "minecraft:carrots", fix: { y: 0 } },
    { typeId: "minecraft:pumpkin_stem", fix: { y: 0 } },
    { typeId: "minecraft:melon_stem", fix: { y: 0 } },
]